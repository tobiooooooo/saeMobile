package com.example.saemobile;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageButton;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private ImageButton menuButton;
    private Button btnDon;
    private Button btnAssociations;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Récupération des boutons
        menuButton = findViewById(R.id.menu_button);
        btnDon = findViewById(R.id.btn_don);
        btnAssociations = findViewById(R.id.btn_associations);

        // Charger l'animation depuis res/anim/click_effect.xml
        Animation clickEffect = AnimationUtils.loadAnimation(this, R.anim.click_effect);

        btnDon.setOnTouchListener((v, event) -> {
            v.startAnimation(clickEffect);
            return false;
        });

        btnAssociations.setOnTouchListener((v, event) -> {
            v.startAnimation(clickEffect);
            return false;
        });

        // Rediriger vers la page de don
        btnDon.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DonActivity.class);
            startActivity(intent);
        });

        // Rediriger vers la page des associations
        btnAssociations.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AssociationActivity.class);
            startActivity(intent);
        });
    }
}
